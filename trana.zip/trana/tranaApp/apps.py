from django.apps import AppConfig


class TranaappConfig(AppConfig):
    name = 'tranaApp'
