email = r"medtrana2020@gmail.com"
pwd = r"covidproject2020"